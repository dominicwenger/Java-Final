package application;

import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;


public class controller {
	Stage stage;
	Scene scene;
	Parent root;
	
	
	public void BackToMain(ActionEvent event) throws IOException
	{
		Parent root = FXMLLoader.load(getClass().getResource("Main Menu.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}
	public void Arg(ActionEvent event) throws IOException
	{
		Parent root = FXMLLoader.load(getClass().getResource("Arg.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}
	public void Bra(ActionEvent event) throws IOException
	{
		Parent root = FXMLLoader.load(getClass().getResource("Bra.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}
	public void Col(ActionEvent event) throws IOException
	{
		Parent root = FXMLLoader.load(getClass().getResource("Col.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}
	public void Guy(ActionEvent event) throws IOException
	{
		Parent root = FXMLLoader.load(getClass().getResource("Guy.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}
	public void Per(ActionEvent event) throws IOException
	{
		Parent root = FXMLLoader.load(getClass().getResource("Per.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}
	public void Uru(ActionEvent event) throws IOException
	{
		Parent root = FXMLLoader.load(getClass().getResource("Uru.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}
	public void Bol(ActionEvent event) throws IOException
	{
		Parent root = FXMLLoader.load(getClass().getResource("Bol.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}
	public void Chi(ActionEvent event) throws IOException
	{
		Parent root = FXMLLoader.load(getClass().getResource("Chi.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}
	public void Ecu(ActionEvent event) throws IOException
	{
		Parent root = FXMLLoader.load(getClass().getResource("Ecu.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}
	public void Par(ActionEvent event) throws IOException
	{
		Parent root = FXMLLoader.load(getClass().getResource("Par.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}
	public void Sur(ActionEvent event) throws IOException
	{
		Parent root = FXMLLoader.load(getClass().getResource("Sur.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}
	public void Ven(ActionEvent event) throws IOException
	{
		Parent root = FXMLLoader.load(getClass().getResource("Ven.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}
	
	

	public void Exit()
	{
		Exit();
	}
	
	

}


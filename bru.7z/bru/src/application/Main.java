// Name: Dominic Wenger //
// Date: 12/12/2021 //
// Project: Final //
// Description: Allow user to learn out about the different South American Countries by seeing pictures such as their national bird, flower, capital, and nature.
package application;
	
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.scene.Parent;
import javafx.scene.Scene;


public class Main extends Application {
	@Override
	public void start(Stage stage)
	{
		try
		{
			Parent root = FXMLLoader.load(getClass().getResource("Main Menu.fxml"));
			Scene scene = new Scene(root);
			stage.setScene(scene);
			stage.show();
		} catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}
